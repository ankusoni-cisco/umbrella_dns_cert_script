####################################################################################################################################################
# This script is to copy the Umbrella rootCA to all edge routers from vManage through system IP connection.
#  
# Script does the following:
#      - Ssh to edge router
#      - Create Umbrella rootCA on edge router to /bootflash/sdwan/trustidrootx3_ca_062035.ca
#      - Copy rooCA file from /bootflash/sdwan/trustidrootx3_ca_062035.ca to bootflash:trustidrootx3_ca_092024.ca
#
# Use "python3 umbrella_rootca_script.py --help" to find all available args.
#  
# Script takes csv file as input which should contain router ip, username and password with comma separated format. 
#
# If all the routers has same username and password, then instead of mentioning username/password per router in csv file, arg "-u" and "-p" option can be used.
# 
# At the end of the run, script will show results with how many routers are updated and failed. 
# For the failed routers, script will create failed_routers.csv which will contain all failed routers systemt ip..
# 
# Script has to be run on vManage shell
# If the deployment is with multi nodes cluster vManages, this script has to be run on all vManage nodes in the cluster.
# 
####################################################################################################################################################
import paramiko
import time
import csv
import glob
import argparse
import subprocess
import shutil
import logging
import sys

def read_routers_from_csv(csv_file):
    routers = []
    try:
        with open(csv_file, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                routers.append(row)
    except FileNotFoundError:
        logger.error(f"Error: The file {csv_file} was not found.")
    return routers

def ssh_to_router(host, username, password):
    result = ['', '']
    # Create an SSH client
    ssh = paramiko.SSHClient()

    # Load system host keys
    ssh.load_system_host_keys()

    # Automatically add the host key if not present
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        # Connect to the router
        logger.info(f"Connecting to {host}...")
        ssh.connect(hostname=host, username=username, password=password, port=830, timeout=5)

        # Open an interactive shell session
        shell = ssh.invoke_shell()
        time.sleep(1)  # Allow the shell to initialize

        shell.send("\n")
        time.sleep(3)
        output = shell.recv(3000).decode('utf-8')
        
        if "Password:" in output:
            # Send the command to the router
            shell.send(password + "\n")
            time.sleep(3)
            output = shell.recv(3000).decode('utf-8')

        if "Password:" in output:
            # Send the command to the router
            shell.send(password + "\n")
            time.sleep(3)
            output = shell.recv(3000).decode('utf-8')

        if '#' in output:
            result = [ssh, shell]
        else:
            logger.error("Failed to get prompt after ssh login")

    except Exception as e:
        logger.error("Failed to ssh to host %s: %s" % (host,e))

    finally:
        # Close the connection
        return result

def createRootCA(shell):
    try:
        # Send the command to the router
        command = "terminal shell"
        shell.send(command + "\n")
        time.sleep(1)
        output = shell.recv(3000).decode('utf-8')

        cert_cmd_list = [
            'UMBRELLA_2035_CERT="-----BEGIN CERTIFICATE-----',
            'MIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw',
            'TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh',
            'cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4',
            'WhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu',
            'ZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY',
            'MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc',
            'h77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+',
            '0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U',
            'A5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW',
            'T8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH',
            'B5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC',
            'B5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv',
            'KBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn',
            'OlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn',
            'jh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw',
            'qHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI',
            'rU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV',
            'HRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq',
            'hkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL',
            'ubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ',
            '3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK',
            'NFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5',
            'ORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur',
            'TkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC',
            'jNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc',
            'oyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq',
            '4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA',
            'mRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d',
            'emyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=',
            '-----END CERTIFICATE-----"'
        ]
        for command in cert_cmd_list:
           # Send the command to the router
           shell.send(command + "\n")
           time.sleep(1)
           output = shell.recv(3000).decode('utf-8')

        command = 'printf "%s" "$UMBRELLA_2035_CERT" > bootflash:sdwan/trustidrootx3_ca_062035.ca'
        shell.send(command + "\n")
        time.sleep(2)
        output = shell.recv(3000).decode('utf-8')
        
        command = 'terminal no shell'
        shell.send(command + "\n")
        time.sleep(2)
        output = shell.recv(3000).decode('utf-8')

        command = 'verify /md5 bootflash:sdwan/trustidrootx3_ca_062035.ca'
        shell.send(command + "\n")
        time.sleep(2)

        # Capture the final output
        final_output = shell.recv(3000).decode('utf-8')
        if "verify" in final_output:
            return True
        logger.error("Failed to create rootCA on router %s" % (host))
        return False
    except Exception as e:
        logger.error("Failed to create rootCA on router %s: %s" % (host,e))
        return False

def scpRootCA(ssh,shell):
    try:
        from scp import SCPClient
        scp = SCPClient(ssh.get_transport())
        scp.put(r'trustidrootx3_ca_062035.ca', r'/bootflash/sdwan/trustidrootx3_ca_062035.ca')
        return True
    except Exception as e:
        logger.error(f"Error occurred while trying ssh to {host}: {str(e)}")
        return False
    
def copyRootCA(host, username, password, vmanage_version, version):
    try:
        # ssh to router
        result = ssh_to_router(host, username, password)
        ssh = result[0]
        shell = result[1]
        if not ssh and not shell:
            logger.error("Control connections might be down or router conected to other vManage nodes in the cluster")
            return False
        
        logger.info("Creating root CA file...")
        
        # Create rootCA file in bootflash:
        if '20.12' in vmanage_version or \
            '20.13' in vmanage_version or \
                '20.14' in vmanage_version or \
                    '20.15' in vmanage_version:
            
            result = scpRootCA(ssh, shell)
        else:
            result = createRootCA(shell)
        if not result:
            return False

        # Command that requires confirmation (Destination filename prompt)
        if '17.03' in version or '17.04' in version or '17.05' in version:
            command = "copy bootflash:sdwan/trustidrootx3_ca_062035.ca bootflash:trustidrootx3_ca.ca"
        else:
            command = "copy bootflash:sdwan/trustidrootx3_ca_062035.ca bootflash:trustidrootx3_ca_092024.ca"
        logger.info("Copying root CA file...")
        
        # Send the command to the router
        shell.send(command + "\n")

        # Wait for the prompt for the destination filename and send "Enter"
        time.sleep(5)  # Adjust based on the time the router takes to prompt
        output = shell.recv(3000).decode('utf-8')

        if "Destination filename" in output:
            # Simulate pressing Enter to accept the default filename
            shell.send("\n")

            # Wait for the operation to complete
            time.sleep(2)  # Adjust timing as needed
            output = shell.recv(3000).decode('utf-8')

        if "Do you want to over write?" in output:
            # Simulate pressing Enter to accept the overwrite filename
            shell.send("\n")

            # Wait for the operation to complete
            time.sleep(2)  # Adjust timing as needed
            output = shell.recv(3000).decode('utf-8')

        if "Copy in progress" in output:
            result = True
        else:
            result = False
            logger.error('Failed in copying rootCA file to bootflash') 

        shell.close()
        ssh.close()
        logger.info("Closing ssh connection")
        return result
    except Exception as e:
        logger.error(f"Error copying rootCA on {host}: {str(e)}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', "--host_csv_file", required=True, help="CSV file with host ip, username and password")
    parser.add_argument('-u', "--username", default="", help="login username for routers. Use this option only if all routers has same userlogin. Else use CSV option")   
    parser.add_argument('-p', "--password", default="", help="login password for routers. Use this option only if all routers has same password. Else use CSV option")   
    parser.add_argument('-v', "--vmanage_version", required=True, help="vManage version like 20.9.5")

    args = parser.parse_args()
    csv_file = args.host_csv_file
    glob_username = args.username
    glob_password = args.password
    vmanage_version = args.vmanage_version
    routers = read_routers_from_csv(csv_file)

    # set logging
    logging.basicConfig(filename="run.log", filemode='w', format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    total_routers = len(routers)
    pending_routers = len(routers)
    pass_routers = 0
    fail_routers = []
 
    # SSH into each router from the CSV file
    for router in routers:
        
        host = router["host"]
        if not glob_username:
            username = router["username"]
        else: 
            username = glob_username
        if not glob_password:
            password = router["password"]
        else: 
            password = glob_password
        
        logger.info("------------------- Total routers: %s  Pending routers: %s -------------------" % (total_routers, pending_routers))
        #Copy rootCA to routers
        if copyRootCA(host, username, password, vmanage_version, router['version']): 
            pass_routers += 1
        else:
            fail_routers.append(host)
        pending_routers -= 1

    logger.info("---------------------------------------------------")
    logger.info("Total routers: %s" % total_routers)
    logger.info("Successfully copied Umbrella rootCA to %s routers" % pass_routers)
    if len(fail_routers) >  0: 
        logger.info("Failed to copy Umbrella rootCA to %s routers" % len(fail_routers))
        logger.info("Failed routers %s" % fail_routers)

        csv_file = "failed_routers.csv"
        with open(csv_file, mode='w', newline='') as file1:
            file1.write('host,username,password \n')
            for router in fail_routers:
                file1.write(router)
                file1.write('\n')


           

