import logging
from datetime import datetime
import requests
import psutil
import socket
import csv
import argparse
import getpass
import sys 

try:
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
except NameError:
    try:
        from requests.packages import urllib3
        urllib3.disable_warnings()
    except:
        pass

# Configure logging
logging.basicConfig(filename='fetch_connected_devices.log', filemode='w', level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

def parse_arguments():
	parser = argparse.ArgumentParser(description='Fetch connected devices')

	parser.add_argument('-u', '--username', type=str, required=True, help="vManage Username")
	parser.add_argument('-p', '--password', type=str, required=False, help="vManage Password")
	args = parser.parse_args()
    
	return args

def get_password(args):
    try:
        password = args.password or getpass.getpass('vManage Password:')
        if not password:
            raise ValueError('Password cannot be empty')
    except Exception as e:
        logger.error(f"Exception occurred: {e}")
        raise SystemExit('ERROR: Invalid Password provided')
    
    return password

def get_jsession_id(ip,username,password,port):
      
	if port==None:
		url = f"https://{ip}:8443/j_security_check"
	else:
		url = f"https://{ip}:{port}/j_security_check"

	payload ={
		"j_username":username,
		"j_password":password
	}

	headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
            }

	response = requests.post(url, headers=headers, data = payload, verify=False)
	if response.status_code == 200:
		jsession_id = (response.headers['Set-Cookie']).split(';')
		return jsession_id[0]
	else:
		logger.error("Error creating jsession ID. Verify if credentials are correct.")


def get_csrf_token(ip,jsession_id,port):

    if port==None:
        url = f"https://{ip}:8443/dataservice/client/token"
    else:
        url = f"https://{ip}:{port}/dataservice/client/token"

    headers = {
        'Cookie' : jsession_id,
    }

    response = requests.get(url, headers=headers, verify=False)

    if response.status_code==200:
        return response.text
    else:
        logger.error("Error creating CSRF Token. Verify if session ID is valid.")

def get_request_json(ip, auth, port, api_endpoint):

    if port==None:
        url = f"https://{ip}:8443/dataservice/{api_endpoint}"
    else:
        url = f"https://{ip}:{port}/dataservice/{api_endpoint}"

    headers = {
        'Accept': 'application/json',
        'Cookie' : auth['jsession_id'],
        'X-XSRF-TOKEN' : auth['csrf_token']
    }

    response = requests.get(url, headers=headers, verify=False)

    if response.status_code==200:
        json_response = response.json()
        return json_response["data"]
    else:
        logger.error("Error in API Call. Verify if session ID is valid.")

def get_edge_info(device_output):
    info = []
    for device in device_output:
        if device['device-type'] == 'vedge':
            vedge_info = {
                'hostname': device.get('host-name', 'no-host-name'),
                'system_ip': device.get('system-ip', 'no-system-ip'),
                'version': device.get('version', 'no-version'),
                'validity': device.get('validity', 'no-validity'),
                'reachability': device.get('reachability', 'no-reachability'),
                'connected_vmanage': device.get('connectedVManages', 'no-reachability'),
            }
            info.append(vedge_info)

    return info

def get_vmanage_system_ip():
    system_ip = ""
    interface_addresses = psutil.net_if_addrs()
    system_interface = interface_addresses['system']
    for entry in system_interface:
        if entry.family == socket.AF_INET:
            system_ip = entry.address
            break

    return system_ip

if __name__ == "__main__":

    host = "localhost"
    port = "8443"
    
    args = parse_arguments()
    password = get_password(args)

    username = args.username
    password = password

    try:
        jsession_id = get_jsession_id(host, username, password, port)
        csrf_token = get_csrf_token(host, jsession_id, port)
        auth = {
            'jsession_id': jsession_id,
            'csrf_token': csrf_token
        }
    except Exception as e:
        logger.error(f"Exception occurred: {e}")
        raise SystemExit('Error: Login failed. Please check credentials.')

    vmanage_system_ip = get_vmanage_system_ip()
    device_api_output = get_request_json(host, auth, port, "device")
    edge_info = get_edge_info(device_api_output)

    reachable_devices = []
    unreachable_devices = []

    for edge in edge_info:
        if edge['reachability'] == "reachable" and edge['version'].startswith("17.") and edge['connected_vmanage'][0] == vmanage_system_ip:
            filtered_edge = {
                'host': edge['system_ip'],
                'version': edge['version'],
                'username': '',
                'password': '',
            }
            reachable_devices.append(filtered_edge)
        elif not edge['reachability'] == "reachable" and edge['version'].startswith("17."):
            unreachable_devices.append(edge)
    logger.info("Fetched all reachable and unreachable routers")
    if reachable_devices:
        with open("reachable_hosts.csv", mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=reachable_devices[0].keys())
            writer.writeheader()
            writer.writerows(reachable_devices)
        logger.info("Created file reachable_hosts.csv which will have all reachable routers system ip")

    if unreachable_devices:
        with open("unreachable_hosts.csv", mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=unreachable_devices[0].keys())
            writer.writeheader()
            writer.writerows(unreachable_devices)
        logger.info("Created file unreachable_hosts.csv which will have all unreachable routers system ip")

